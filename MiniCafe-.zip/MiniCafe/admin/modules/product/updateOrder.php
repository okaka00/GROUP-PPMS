<?php
session_start();
include("config/config.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $reservationID = $_POST["reservationID"];
    $status = $_POST["status"];

    // Validate inputs
    if (!empty($reservationID) && in_array($status, ['1', '2'])) {
        // Update the status in the database
        $sql = "UPDATE reservation SET status = ? WHERE reservationID = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $status, $reservationID);

        if (mysqli_stmt_execute($stmt)) {
            // Redirect back to the order page with a success message
            header("Location: orderList.php?message=Status+updated+successfully");
            exit();
        } else {
            // Redirect back with an error message
            header("Location: orderList.php?error=Failed+to+update+status");
            exit();
        }
    } else {
        // Redirect back with an error message
        header("Location: orderList.php?error=Invalid+input");
        exit();
    }
}
?>