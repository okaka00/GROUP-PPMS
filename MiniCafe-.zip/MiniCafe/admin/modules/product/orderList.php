<?php
//include db config
include("../../config/config.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" type="text/css" href="../../css/admin.css">
    <title>Order List</title>
</head>

<body>
    <div class="topNav">
        <img src="../../img/icon.png" alt="Logo">
    
    </div>

    <?php
    include '../../includes/sideNav.php';
    ?>

    <div class="main">
        <h2 style="text-align: center;">Manage Order List</h2>
        <div class="rowform">
            <?php
            $sql_reservation = "SELECT r.reservationID, r.userID, u.userID, u.userName, r.orderAmt, r.reservationDate, r.status
            FROM reservation r, user u
            WHERE r.userID = u.userID
            ORDER BY r.reservationID ASC";
            $result = mysqli_query($conn, $sql_reservation);
            $rowcount = mysqli_num_rows($result);

            if ($rowcount > 0) {
                // Start the table
                echo "<table border='1' cellpadding='5' cellspacing='0' width='100%'>";
                echo "<tr>";
                echo "<th>Order ID</th>";
                echo "<th>User Name</th>";
                echo "<th>Order Amount</th>";
                echo "<th>Order Date</th>";
                echo "<th>Status</th>";
                echo "<th>Actions</th>";
                echo "</tr>";

                // Dynamically create html table row based on output data of each row from customer table
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["reservationID"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["userName"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["orderAmt"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["reservationDate"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["status"]) . "</td>";
                    echo "<td>";
                    // Add dropdown to change status
                    echo "<form method='POST' action='updateOrder.php'>";
                    echo "<input type='hidden' name='reservationID' value='" . $row["reservationID"] . "'>";
                    echo "<select name='status'>";
                    echo "<option value='Pending'" . ($row["status"] == 1 ? ' selected' : '') . ">Pending</option>";
                    echo "<option value='Completed'" . ($row["status"] == 2 ? ' selected' : '') . ">Completed</option>";
                    echo "</select>";
                    echo "<button type='submit'>Update Status</button>";
                    echo "</form>";
                    echo "<a href='deleteOrder.php?id=" . urlencode($row["reservationID"]) . "' onclick='return confirm(\"Are you sure you want to delete this product?\");'>Delete</a>";
                    echo "</td>";
                    echo "</tr>";
                }

                echo "</table>";

                // Display row and field counts
                echo "<p>Row Count: $rowcount</p>";
            } else {
                echo "<p>No results found.</p>";
            }

            

            echo '</div>';
            echo '</div>';
            // Free result set
            mysqli_free_result($result);
            //close connection
            mysqli_close($conn);
            ?>
            <p><a href="<?php echo ADMIN_BASE_URL; ?>">Admin Page</a></p>
</body>

</html>