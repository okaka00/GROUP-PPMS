<?php
//include db config
include("../../config/config.php");

// Check if ID is provided
if (isset($_GET['id'])) {
    $categoryID = intval($_GET['id']);

    // Another example to retrieve the existing product data using prepared statement
    $sql = "SELECT * FROM category WHERE categoryID = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $categoryID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $categoryName = $row['categoryName'];
        $categoryDesc = $row['categoryDesc'];

    } else {
        echo "Category not found.";
        exit;
    }
    mysqli_stmt_close($stmt);
} else {
    echo "Invalid request.";
    exit;
}

// Handle Product Update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $categoryName = $_POST['categoryName'];
    $categoryDesc = $_POST['categoryDesc'];

    
    // Execute query
    if (mysqli_stmt_execute($stmt)) {
        echo "Product updated successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    // Redirect or display a success message
    header("Location: productList.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" type="text/css" href="../../css/admin.css">
    <title>Edit Category</title>
</head>

<body>
    <div class="topNav">
        <img src="../../img/icon.png" alt="Logo">
        <a href="login.php">
            <i class="fa fa-sign-in" style="font: size 12px;"></i> Login
        </a>
    </div>

    <?php
    include '../../includes/sideNav.php';
    ?>

    <div class="main">
        <h2 style="text-align: center;">Edit Category: <?= $categoryID ?></h2>
        <div class="rowform">
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="categoryID"
                    value="<?= isset($categoryID) ? htmlspecialchars($categoryID) : 'NONE'; ?>">
                <label for="categoryName">Category Name:</label>
                <input type="text" id="categoryName" name="categoryName" value="<?= htmlspecialchars($categoryName) ?>"
                    required><br><br>
                <label for="categoryDesc">Category Description:</label>
                <input type="text" id="categoryDesc" name="categoryDesc" value="<?= htmlspecialchars($categoryDesc) ?>"
                    required><br><br>
                <button type="submit">Update</button>

            </form>
        </div>
    </div>
</body>

</html>