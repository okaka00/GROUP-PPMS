<nav class="topnav" id="myTopnav">
    <a href="index.php">Home</a>
    <a href="aboutMe.php">About Me</a>
    <a href="portfolio.php">Menu</a>
    <a href="my_order.php">My Order</a>
    <a href="blog.php">Blog</a>
    <a href="review.php">Review</a>
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
        <i class="fa fa-bars"></i></a>

    
</nav>